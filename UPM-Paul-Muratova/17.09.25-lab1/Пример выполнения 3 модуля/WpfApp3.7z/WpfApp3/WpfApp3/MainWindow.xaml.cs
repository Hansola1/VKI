﻿using System.Windows;
using System.Windows.Controls;
using WpfApp3.Models;
using WpfApp3.Windows;

namespace WpfApp3
{
    public partial class MainWindow : Window
    {
        public List<Product> Product { get; set; } = AppContext.Products;
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void AddNewProduct(object sender, RoutedEventArgs e)
        {
            WindowAddProduct addProduct = new WindowAddProduct();

            addProduct.ShowDialog();
            if(addProduct.DialogResult == true)
            {
                ListBoxProduct.Items.Refresh();
            }
        }

        private void SelectProduct(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            ListBox listBox = sender as ListBox;

            WindowEditProduct editProduct = new WindowEditProduct(listBox.SelectedItem as Product);

            editProduct.ShowDialog();
            if (editProduct.DialogResult == true)
            {
                ListBoxProduct.Items.Refresh();
            }
        }
    }
}