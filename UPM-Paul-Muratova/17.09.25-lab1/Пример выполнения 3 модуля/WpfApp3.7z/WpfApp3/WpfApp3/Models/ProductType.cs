﻿namespace WpfApp3.Models
{
    public class ProductType
    {
        public int id {  get; set; }
        public string Type { get; set; }
        public double Cof { get; set; }
        public override string ToString()
        {
            return $"{Type}: {Cof}";
        }
    }
}
