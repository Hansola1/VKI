﻿namespace WpfApp3.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Arc { get; set; } = "Arc";
        public ProductType ProductType { get; set; }
        public string Name { get; set; } = "Name";
        public double MinPrice { get; set; } = 3700.01;
        public double WightRoll { get; set; } = 3700.01;
        
    }
}
