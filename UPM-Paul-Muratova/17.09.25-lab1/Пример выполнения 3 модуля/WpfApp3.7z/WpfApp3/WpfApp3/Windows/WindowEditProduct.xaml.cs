﻿using System.Windows;
using WpfApp3.Models;

namespace WpfApp3.Windows
{
    public partial class WindowEditProduct : Window
    {
        public Product Product { get; set; }
        public WindowEditProduct(Product product)
        {
            InitializeComponent();
            Product = product;
            BoxArc.Text = product.Arc;
            BoxMinPrice.Text = product.MinPrice.ToString();
            BoxName.Text = product.Name;
            BoxWightRoll.Text = product.WightRoll.ToString();
            BoxTypeProduct.ItemsSource = AppContext.ProductTypes;
            BoxTypeProduct.SelectedItem = product.ProductType;
        }
        private void ButtonExit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonSaveEdit(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(BoxArc.Text) &&
                !string.IsNullOrEmpty(BoxMinPrice.Text) &&
                !string.IsNullOrEmpty(BoxName.Text) &&
                !string.IsNullOrEmpty(BoxWightRoll.Text) &&
                BoxTypeProduct.SelectedIndex != -1)
            {
                double MinPrice = double.Parse(BoxMinPrice.Text);
                double WightRoll = double.Parse(BoxWightRoll.Text);
                if (MinPrice >= 0 && WightRoll >= 0)
                {
                    Product.Arc = BoxArc.Text;
                    Product.MinPrice = Math.Round(MinPrice, 2);
                    Product.WightRoll = Math.Round(WightRoll, 2);
                    Product.Name = BoxName.Text;
                    Product.ProductType = (ProductType)BoxTypeProduct.SelectedItem;
                    
                    DialogResult = true;
                    MessageBox.Show("Продукт успешно обновлен");
                }
                else
                {
                    MessageBox.Show("Ширина рулона или цена не может быть отрицательной");
                }
            }
            else
            {
                MessageBox.Show("Не все поля были заполнены");
            }
        }
    }
}
