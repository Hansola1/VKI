﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp3.Models;

namespace WpfApp3.Windows
{
    /// <summary>
    /// Логика взаимодействия для WindowAddProduct.xaml
    /// </summary>
    public partial class WindowAddProduct : Window
    {
        public WindowAddProduct()
        {
            InitializeComponent();
            BoxTypeProduct.ItemsSource = AppContext.ProductTypes;
            BoxTypeProduct.SelectedIndex = 0;
        }

        private void ButtonExit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtAddProduct(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(BoxArc.Text) &&
                !string.IsNullOrEmpty(BoxMinPrice.Text) &&
                !string.IsNullOrEmpty(BoxName.Text) &&
                !string.IsNullOrEmpty(BoxWightRoll.Text) &&
                BoxTypeProduct.SelectedIndex != -1)
            {
                double MinPrice = double.Parse(BoxMinPrice.Text);
                double WightRoll = double.Parse(BoxWightRoll.Text);
                if (MinPrice >= 0 && WightRoll >= 0)
                {
                    Product newProduct = new Product()
                    {
                        Id = 1,
                        Arc = BoxArc.Text,
                        MinPrice = Math.Round(MinPrice, 2),
                        WightRoll = Math.Round(WightRoll, 2),
                        Name = BoxName.Text,
                        ProductType = (ProductType)BoxTypeProduct.SelectedItem
                    };
                    AppContext.Products.Add(newProduct);
                    DialogResult = true;
                    MessageBox.Show("Продукт успешно добавлен");
                }
                else
                {
                    MessageBox.Show("Ширина рулона или цена не может быть отрицательной");
                }
            }
            else
            {
                MessageBox.Show("Не все поля были заполнены");
            }
        }
    }
}
