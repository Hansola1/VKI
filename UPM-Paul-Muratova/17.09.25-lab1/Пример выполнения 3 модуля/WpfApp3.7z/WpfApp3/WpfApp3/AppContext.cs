﻿using WpfApp3.Models;

namespace WpfApp3
{
    public static class AppContext
    {
        public static List<ProductType> ProductTypes { get; set; } = new()
        {
            new()
            {
                id = 1,
                Type = "Декоративные обои",
                Cof = 5.5
            },
            new()
            {
                id = 1,
                Type = "Фотообои",
                Cof =7.54
            },
            new()
            {
                id = 1,
                Type = "Обои под покраску",
                Cof = 3.25
            }
        };
        public static List<Product> Products { get; set; } = new();
    }
}
