﻿using Biblio.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;


namespace Biblio
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Book> books = new List<Book>();
        public MainWindow()
        {
            InitializeBooks();
            InitializeComponent();
            ListBooks.ItemsSource = books;
        }

        private void InitializeBooks()
        {
 
            books.Add(new Book(1468, "Л.Н. Толстой", "Война и мир", 1867, 1));
            books.Add(new Book(1469, "Л.Н. Толстой", "Анна Каренина", 1877, 1));
            books.Add(new Book(1470, "Л.Н. Толстой", "Анна Каренина", 2023, 10));
        }
        public void SearchBookClick(object sender, RoutedEventArgs e)
        {
            
            Book book = null;
            TextBlock searchBlock = (TextBlock)Choose.SelectedItem;
            switch (searchBlock.Text)
            {
                case "Артикул":

                    if (!int.TryParse(FindBookInput.Text, out int request))
                    {
                        BookInfoTextBlock.Text = "Введены неккоректные данные";
                        return;
                    }
                    book = books.Find(x => x.Id == request);
                    break;
                case "Автор":
                    book = books.Find(x => x.Author == FindBookInput.Text);
                    break;
                case "Название":
                    book = books.Find(x => x.Title == FindBookInput.Text);
                    break;

            }
     
          

            BookInfoTextBlock.Text = book is null ? "Такой книги нет в каталоге ":book.ToString();
                  
        }

    }
}
